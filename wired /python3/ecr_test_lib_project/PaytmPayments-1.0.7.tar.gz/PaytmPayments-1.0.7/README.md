## Python Library for EDC wired Integration

This README would document whatever steps are necessary to get your application up and running.

### What is this repository for?

This project is for integrating wired EDC devices with merchant billing system written in python.

Latest Version : 1.0.1

### Requirements

python '>=3.6' version required.

### How to use

change to project directory
```
cd <your_project>/
```
create python virtualenv for project
```
python3 -m venv env
```
activate virtualenv
```
source env/bin/activate
```

### Installation
add package tar file path in requirements.txt
```
pip install -r requirements.txt
```


create test.py and place this code

```from payments import payments
p = payments.Payments()
resp = p.ConnectionCheck("/dev/tty.usbmodem14930718862", 115200, 0, 8, 1, 0)
print(resp)
```
run test.py
```
python3 test.py
```
Successful connection
```
{"statusCode":"000","statusMessage":"Command Initiated Successfully"}
```


### ConnectionCheck arguments
ConnectionCheck(port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int)
