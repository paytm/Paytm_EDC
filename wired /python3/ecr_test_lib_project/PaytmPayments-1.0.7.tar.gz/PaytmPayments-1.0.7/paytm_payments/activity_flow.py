import paytm_payments.models
import paytm_payments.constants
import paytm_payments.utils
import paytm_payments.checksum
from typing import NewType
PrintReceiptRequestData = NewType('PrintReceiptRequestData', paytm_payments.models.PrintReceiptRequestData)
ConnectionCheckRequest = NewType('ConnectionCheckRequest', paytm_payments.models.ConnectionCheckRequest)
PrintReceiptRequest = NewType('PrintReceiptRequest', paytm_payments.models.PrintReceiptRequest)
CancelRequestData = NewType('CancelRequestData', paytm_payments.models.CancelRequestData)
StatusRequestData = NewType('StatusRequestData', paytm_payments.models.StatusRequestData)
SaleRequestData = NewType('SaleRequestData', paytm_payments.models.SaleRequestData)
VoidRequestData = NewType('VoidRequestData', paytm_payments.models.VoidRequestData)
CancelRequest = NewType('CancelRequest', paytm_payments.models.CancelRequest)
VoidRequest = NewType('VoidRequest', paytm_payments.models.VoidRequest)
SaleRequest = NewType('SaleRequest', paytm_payments.models.SaleRequest)

class ConnectionCheckActivityFlow:
    def process(self, request_id: str, debug_mode: bool):
        req_data: str = self.request_data(request_id=request_id)
        if req_data:
            return req_data
        else:
            return ""


    def request_data(self, request_id: str):
        request_data: str = paytm_payments.models.ConnectionCheckRequest(paytm_payments.constants.Command.connection_check, request_id).to_string()
        return request_data
    
class PrintReceiptActivityFlow:
    print_request_data: PrintReceiptRequestData = None

    def process(self, merchant_id: str, order_id: str, request_id: str, debug_mode: bool):
        print_req_data = paytm_payments.models.PrintReceiptRequestData(merchant_id, order_id)
        json_print_req_data = print_req_data.to_string()
        req_data_checksum = paytm_payments.checksum.HashHelper.compute_sha_256(json_print_req_data)
        req_data = self.request_data(print_req_data, req_data_checksum, request_id)
        if req_data:
            return req_data
        return ""
 

    def request_data(self, req_data: PrintReceiptRequestData, req_data_checksum: str, request_id: str):

        request_data: PrintReceiptRequest = paytm_payments.models.PrintReceiptRequest(paytm_payments.constants.Command.print_receipt, req_data, req_data_checksum, request_id)
        req_data_str = request_data.to_string()
        return req_data_str
    
class SaleActivityFlow:
    def process(self, merchant_id: str, order_id: str, payment_mode: str, amount: str, sub_wallet_info: str, request_id: str, debug_mode: int, extend_info: str, print_info: str, gst_information: str, card_read_mode: str):
        sale_data = paytm_payments.models.SaleRequestData(merchant_id,order_id, payment_mode,
                                                    amount, sub_wallet_info,extend_info,
                                                    print_info, gst_information, card_read_mode)
        req_data_checksum = paytm_payments.checksum.HashHelper.compute_sha_256(sale_data.to_string())
        req_data = self.request_data(sale_data, req_data_checksum, request_id)

        if req_data:
            return req_data
        return ""

    def request_data(self, req_data: SaleRequestData, req_data_checksum: str, req_id: str):
        sale_request: SaleRequest = paytm_payments.models.SaleRequest(paytm_payments.constants.Command.process_transaction, req_data, req_data_checksum, req_id)
        request_data = sale_request.to_string()
        return request_data
    
class StatusActivityFlow:

    def process(self, merchant_id: str, order_id: str, request_id: str, debug_mode: int):
        status_data = paytm_payments.models.StatusRequestData(merchant_id, order_id)

        req_data_checksum = paytm_payments.checksum.HashHelper.compute_sha_256(status_data.to_string())

        request_data = self.request_data(status_data, req_data_checksum, request_id)

        if request_data:
            return request_data
        return ""

    def request_data(self, req_data: SaleRequestData, req_data_checksum: str, request_id: str):
        request_data = paytm_payments.models.StatusRequest(paytm_payments.constants.Command.status_query, req_data,
                                                         req_data_checksum, request_id)
        
        return request_data.to_string()
    
class CancelActivityFlow:

    def process(self, merchant_id: str, order_id: str, request_id: str, debug_mode: int):
        cancel_data: CancelRequestData = paytm_payments.models.CancelRequestData(merchant_id, order_id)
        req_data_checksum = paytm_payments.checksum.HashHelper.compute_sha_256(cancel_data.to_string())
        req_data = self.request_data(cancel_data, req_data_checksum, request_id)

        if req_data:
            return req_data
        return ""
    
    def request_data(self, req_data: CancelRequestData, req_data_checksum: str, request_id: str):
        request_data: CancelRequest = paytm_payments.models.CancelRequest(paytm_payments.constants.Command.cancel_transaction, req_data, req_data_checksum, request_id)
        return request_data.to_string()
    
class VoidActivityFlow:

    def process(self, merchant_id: str, order_id: str, request_id: str, extend_info: str, print_info: str, debug_mode: int):
        void_data: VoidRequestData = paytm_payments.models.VoidRequestData(merchant_id, order_id, extend_info, print_info)
        req_data_checksum = paytm_payments.checksum.HashHelper.compute_sha_256(void_data.to_string())
        req_data = self.request_data(void_data, req_data_checksum, request_id)
        if req_data:
            return req_data
        return ""

    def request_data(self, req_data: VoidRequestData, req_data_checksum: str, request_id: str):
        request_data: VoidRequest = paytm_payments.models.VoidRequest(paytm_payments.constants.Command.void_transaction, req_data, req_data_checksum, request_id)
        return request_data.to_string()
    