import hashlib
import paytm_payments.models
import paytm_payments.utils
from typing import NewType
import paytm_payments.constants

DeviceResponse = NewType('DeviceResponse', paytm_payments.models.DeviceResponse)
ErrorResponse = NewType('ErrorResponse', paytm_payments.models.ErrorResponse)

class HashHelper:
    @staticmethod
    def compute_sha_256(message):
        if type(message) == str:
            message = bytes(message, 'utf-8')
        if type(message) != bytes:
            # payments.utils.add_logs("compute_sha_256() message should be either string or bytes", True)
            raise Exception("message should be string or bytes type")

        return hashlib.sha256(message).hexdigest().upper()

    @staticmethod
    def verify_sha_256(message, checksum):
        if HashHelper.compute_sha_256(message).upper() == checksum:
            # payments.utils.add_logs("verify_sha_256() Checksum Validated : returning true", True)
            return True
        
        # payments.utils.add_logs("verify_sha_256() Invalid Checksum : returning false", True)
        return False
    @staticmethod
    def parse_response_data(response_data: DeviceResponse):
        if response_data and isinstance(response_data, paytm_payments.models.DeviceResponse):
            if HashHelper.verify_sha_256(response_data.data, response_data.checksum):
                # payments.utils.add_logs(f"parse_response_data {response_data.data}", True)
                return response_data.data
            else:
                response_data_str: ErrorResponse = paytm_payments.models.ErrorResponse(paytm_payments.constants.ErrorType.InvalidChecksum.name)
                # payments.utils.add_logs(f"parse_response_data {response_data_str.to_string()}", True)
                return response_data_str.to_string()
        elif response_data and isinstance(response_data, paytm_payments.models.ErrorResponse):
            return response_data.to_string()
        else:
            #:TODO
            response_data_str: ErrorResponse = paytm_payments.models.ErrorResponse(paytm_payments.constants.ErrorType.Timeout.name)
            # payments.utils.add_logs(f"parse_response_data {response_data_str.to_string()}", True)
            return response_data_str.to_string()