import paytm_payments.constants
import json

class DeviceResponse:

    def __init__(self, checksum: str , data: str, response: str, request_id: str) -> None:
        self.checksum = checksum
        self.data = data
        self.response = response
        self.request_id = request_id

class ErrorResponse:


    def __init__(self, status_message: str) -> None:

        self.status_type = "Error"

        if status_message == paytm_payments.constants.ErrorType.Timeout.name:
            self.status_code = str(paytm_payments.constants.ErrorType.Timeout.value)
            self.status_message = "Timeout"
        elif status_message == paytm_payments.constants.ErrorType.InvalidChecksum.name:
            self.status_code = str(paytm_payments.constants.ErrorType.InvalidChecksum.value)
            self.status_message = "Checksum Validation"
        elif status_message == paytm_payments.constants.ErrorType.DeviceNotAvailable.name:
            self.status_code = str(paytm_payments.constants.ErrorType.DeviceNotAvailable.value)
            self.status_message = "Device is not available"
        else:
            self.status_code = str(paytm_payments.constants.ErrorType.GenericError.value)
            self.status_message = status_message

    def to_string(self) -> str:
        return json.dumps({"statusType": self.status_type,
                           "statusCode": self.status_code,
                           "statusMessage": self.status_message},separators=(',', ':'), sort_keys=True)
    
    def get_status_type(self) -> str:
        return self.status_type
    
    def set_status_type(self, status_type: str) -> None:
        self.status_type = status_type

    def get_status_code(self) -> str:
        return self.status_code
    
    def set_status_code(self, status_code) -> None:
        self.status_code = status_code

    def get_status_message(self) -> str:
        return self.status_message
    
    def set_status_message(self, status_message) -> None:
        self.status_message = status_message

class PrintReceiptRequestData:

    def __init__(self, merchant_id: str, order_id: str) -> None:
        self.merchant_id = merchant_id
        self.order_id = order_id

    def get_merchant_id(self) -> str:
        return self.merchant_id
    
    def set_merchant_id(self, merchant_id: str) -> None:
        self.merchant_id = merchant_id

    def get_order_id(self) -> str:
        return self.order_id
    
    def set_order_id(self, order_id: str) -> None:
        self.order_id = order_id

    def to_dict(self):
        data =  {"orderId": self.order_id}
        
        if self.merchant_id:
            data["merchantId"] = self.merchant_id

        return data

    def to_string(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, separators=(',', ':'))
    
class PrintReceiptRequest:

    def __init__(self, command, data: PrintReceiptRequestData, checksum: str, request_id: str):
        self.command = command.name
        self.data = data
        self.checksum = checksum
        self.request_id = request_id

    def to_string(self) -> str:
        return json.dumps({"command": self.command,
                           "checksum": self.checksum,
                           "data": self.data.to_dict(),
                           "requestId": self.request_id}, sort_keys=True, separators=(',', ':'))



class ConnectionCheckRequest:

    def __init__(self, command, request_id: str) -> None:
        # command should be enum type
        self.command: str = command.name
        self.request_id: str = request_id

    def get_command(self) -> str:
        return self.command
    
    def set_command(self, command: str) -> None:
        self.command = command

    def get_request_id(self) -> str:
        return self.request_id
    
    def set_request_id(self, request_id: str) -> None:
        self.request_id = request_id

    def to_string(self) -> str:
        return json.dumps({"command": self.command,
                           "requestId": self.request_id}, sort_keys=True, separators=(',', ':'))
    
class SaleRequestData:
    def __init__(self, merchant_id: str, order_id: str, payment_mode: str, amount: str, sub_wallet_info: str, extend_info: str, print_info: str, gst_information: str, card_read_mode: str):
        self.merchant_id = merchant_id
        self.order_id = order_id
        self.payment_mode = payment_mode
        self.amount = amount
        self.sub_wallet_info = sub_wallet_info
        self.extend_info = extend_info
        self.print_info = print_info
        self.gst_information = gst_information
        self.card_read_mode = card_read_mode

    def to_dict(self) -> dict:
        data = {
                "orderId": self.order_id,
                "paymentMode": self.payment_mode,
                "amount": self.amount}
        
        if self.merchant_id:
            data["merchantId"] = self.merchant_id

        if self.sub_wallet_info:
            data["SubWalletInfo"] = self.sub_wallet_info
        
        if self.extend_info:
            data["extendInfo"] = self.extend_info

        if self.print_info:
            data["printInfo"] = self.print_info

        if self.gst_information:
            data["gstInformation"] = self.gst_information
        
        if self.card_read_mode:
            data["cardReadMode"] = self.card_read_mode

        return data
    
    def to_string(self):
        data = self.to_dict()
        return json.dumps(data, sort_keys=True, separators=(',', ':'))
    
class SaleRequest:
    def __init__(self, command, data: SaleRequestData, checksum: str, request_id: str):
        self.command = command.name
        self.data = data
        self.checksum = checksum
        self.request_id = request_id

    def to_string(self) -> str:
        return json.dumps({"command": self.command,
                           "data": self.data.to_dict(),
                           "checksum": self.checksum,
                           "requestId": self.request_id}, sort_keys=True, separators=(',', ':'))

class StatusRequestData:
    def __init__(self, merchant_id: str, order_id: str):
        self.merchant_id = merchant_id
        self.order_id = order_id

    def to_dict(self):
        data = {
            "orderId": self.order_id
        }

        if self.merchant_id:
            data["merchantId"] = self.merchant_id

        return data
    def to_string(self):
        return json.dumps(self.to_dict(), sort_keys=True, separators=(',', ':') )

class StatusRequest:

    def __init__(self, command, data: StatusRequestData, checksum: str, request_id: str):
        self.command = command.name
        self.data = data
        self.checksum = checksum
        self.request_id = request_id

    def to_string(self) -> str:
        return json.dumps({
            "command": self.command,
            "data": self.data.to_dict(),
            "checksum": self.checksum,
            "requestId": self.request_id
        }, sort_keys=True, separators=(',', ':'))
    
class VoidRequestData:
    def __init__(self, merchant_id: str, order_id: str, extend_info: str, print_info: str):
        self.merchant_id = merchant_id
        self.order_id = order_id
        self.extend_info = extend_info
        self.print_info = print_info

    def to_dict(self):
        data = {"orderId": self.order_id}
        
        if self.merchant_id:
            data["merchantId"] = self.merchant_id

        if self.extend_info:
            data["extendInfo"] = self.extend_info

        if self.print_info:
            data["printInfo"] = self.print_info

        return data
    
    def to_string(self):
        return json.dumps(self.to_dict(), sort_keys=True, separators=(',', ':'))
    
class VoidRequest:
    def __init__(self, command, data: VoidRequestData, checksum: str, request_id):
        self.command = command.name
        self.data = data
        self.checksum = checksum
        self.request_id = request_id

    def to_string(self):
        return json.dumps({
            "command": self.command,
            "data": self.data.to_dict(),
            "checksum": self.checksum,
            "requestId": self.request_id
        }, sort_keys=True, separators=(',', ':'))
    
class CancelRequestData:

    def __init__(self, merchant_id, order_id):
        self.merchant_id = merchant_id
        self.order_id = order_id

    def to_dict(self):
        data = {"orderId": self.order_id}
        
        if self.merchant_id:
            data["merchantId"] = self.merchant_id
        
        return  data
    
    def to_string(self):
        return json.dumps(self.to_dict(), sort_keys=True, separators=(',', ':'))
    
class CancelRequest:
    def __init__(self, command, data: CancelRequestData, checksum: str, request_id: str):
        self.command = command.name
        self.data = data
        self.checksum = checksum
        self.request_id = request_id
    
    def to_string(self):
        return json.dumps({
            "command": self.command,
            "data": self.data.to_dict(),
            "checksum": self.checksum,
            "requestId": self.request_id
        }, sort_keys=True, separators=(',', ':'))
    