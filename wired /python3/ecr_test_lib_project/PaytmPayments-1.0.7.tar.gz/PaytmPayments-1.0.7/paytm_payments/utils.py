import logging
import time
logger = logging.getLogger('paytmpayments')

def add_logs(message: str, debug: bool = False):
    if debug:
        logger.debug(message)

def add_exception_logs(message: str, debug: bool = False):
    if debug:
        logger.exception(message)

def date_time_now():
    return round(time.time()*1000)