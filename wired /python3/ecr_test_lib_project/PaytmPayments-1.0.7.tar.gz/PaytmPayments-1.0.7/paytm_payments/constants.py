from enum import Enum

class ErrorType(Enum):
    NULL = 0
    DeviceNotAvailable = 1100
    Timeout = 1101
    InvalidChecksum = 1102
    GenericError = 1103

class Command(Enum):
    NULL = 0
    process_transaction = 1
    void_transaction = 2
    cancel_transaction =3
    status_query = 4
    connection_check = 5
    print_receipt = 6
    read_card = 7
    read_card_status = 8
    add_money = 9
    update_balance = 10
    create_service = 11
    create_service_status = 12
    check_balance = 13
    check_balance_status = 14
    update_card = 15
    update_card_status = 16

class ParityBits(Enum):
    N = 0     #   PARITY_NONE
    E = 2     #   PARITY_EVEN
    O = 1     #   PARITY_ODD
    M = 3     #   PARITY_MARK
    S = 4     #   PARITY_SPACE


if __name__ == "__main__":
    print("NULL" == ErrorType.NULL.name)
    print(0 == ErrorType.NULL.value)