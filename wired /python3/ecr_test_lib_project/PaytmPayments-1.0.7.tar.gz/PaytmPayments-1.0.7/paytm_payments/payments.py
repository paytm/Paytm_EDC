import serial
import time
import json
import os
import os.path
import traceback
import paytm_payments.models
import paytm_payments.constants
import paytm_payments.utils
import paytm_payments.checksum
import paytm_payments.activity_flow
from serial.tools.list_ports import comports
from typing import NewType
import paytm_payments.utils
SerialPort = NewType('SerialPort', serial.Serial)
DeviceResponse = NewType('DeviceResponse', paytm_payments.models.DeviceResponse)
PrintReceiptActivityFlow = NewType('PrintReceiptActivityFlow', paytm_payments.activity_flow.PrintReceiptActivityFlow)
SaleActivityFlow = NewType('SaleActivityFlow', paytm_payments.activity_flow.SaleActivityFlow)
StatusActivityFlow = NewType('StatusActivityFlow', paytm_payments.activity_flow.StatusActivityFlow)
CancelActivityFlow = NewType('CancelActivityFlow', paytm_payments.activity_flow.CancelActivityFlow)
VoidActivityFlow = NewType('VoidActivityFlow', paytm_payments.activity_flow.VoidActivityFlow)

class Payments:

    cwd = os.getcwd()
    CONFIG_FILE_PATH = f"{cwd}/PaytmPayments.json"

    def __disconnect(self, serial_port: SerialPort, debug_mode: int) -> bool:
        try:
            if serial_port:
                paytm_payments.utils.add_logs("disconnect() :: method just called", debug_mode)
                serial_port.close()
                paytm_payments.utils.add_logs("disconnect() :: serial_port.close() finish", debug_mode)
                return True
            else:
                paytm_payments.utils.add_logs("disconnect() :: serial_port is null, returning false from here", debug_mode)
                return False
        except Exception:
            paytm_payments.utils.add_exception_logs(f"disconnect() {traceback.format_exc()}", debug_mode)
            return False

    def __connect(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, timeout: float, debugmode: int) -> SerialPort:
        
        parity = paytm_payments.constants.ParityBits(parity).name
        
        serial_port_settings = {
            "baudrate": baud_rate,
            "parity": parity,
            "bytesize": databits,
            "stopbits": stopbit
        }
        for i in range(2):
            paytm_payments.utils.add_logs("connect() :: method just called", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
            serial_port: SerialPort = None

            try:
                rts_enabled: bool = True
                dtr_enabled: bool = True
                serial_port = serial.Serial(port=port_name, rtscts=rts_enabled, dsrdtr=dtr_enabled, timeout=timeout)


                if not serial_port.is_open:
                    serial_port.open()

                    if serial_port.is_open:
                        paytm_payments.utils.add_logs("connect() :: port has been opened now", debugmode)
                        serial_port.apply_settings(serial_port_settings)
                    else:
                        paytm_payments.utils.add_logs("connect() :: can't open port", debugmode)
                        serial_port = None
                        raise serial.SerialException(port_name, "open()", "Cannot open port")
                else:
                    paytm_payments.utils.add_logs("connect() :: port is already open", debugmode)
                    serial_port.apply_settings(serial_port_settings)
                return serial_port
            except serial.SerialException:
                paytm_payments.utils.add_exception_logs(f"connect() {traceback.format_exc()}", debugmode)
                if serial_port:
                    self.__disconnect(serial_port=serial_port, debug_mode=debugmode)
                    serial_port = None
                port_name = self.__get_port_no(debugmode)
                if not port_name:
                    return None
            except Exception:
                if serial_port:
                    self.__disconnect(serial_port=serial_port, debug_mode=debugmode)
                    serial_port = None
                paytm_payments.utils.add_exception_logs(f"connect() {traceback.format_exc()}", debugmode)
    
    def __clear_buffers(self, serial_port: SerialPort, debug_mode: bool):
        try:
            if serial_port and serial_port.is_open:
                serial_port.reset_input_buffer()
                serial_port.reset_output_buffer()
                paytm_payments.utils.add_logs(f"clear_buffers() :: IN/OUT buffers purged", debug_mode)
        except Exception:
            paytm_payments.utils.add_exception_logs(f"clear_buffers() {traceback.format_exc()}", debug_mode)

    def __read_write_on_terminal(self, port_name: str, baud_rate: int, parity: int, data_bits: int, stop_bit: int, debug_mode: str, request_id: str, order_id: str, request: str):
        device_response: DeviceResponse = None
        response: str = ""
        serial_port: SerialPort = None

        try:

            if not os.path.isfile(Payments.CONFIG_FILE_PATH):
                raise Exception("Please provide PaytmPayments.json at root path of project")
            
            with open(Payments.CONFIG_FILE_PATH) as user_file:
                file_contents = user_file.read()
            file_contents = json.loads(file_contents)

            read_write_timeout = file_contents.get("ReadWriteOnTerminalTimeout", 6)

            serial_port = self.__connect(port_name, baud_rate, parity, data_bits, stop_bit, float(read_write_timeout), debug_mode)

            if serial_port:
                request_data_length: str = "{:04n}".format(len(request))
                request = request_data_length+request
                self.__clear_buffers(serial_port=serial_port, debug_mode=debug_mode)
                request = bytes(request, 'utf-8')
                written_bytes = serial_port.write(request)
                paytm_payments.utils.add_logs(f"read_write_on_terminal() :: Request Send To Device :: Total bytes written : {written_bytes}", debug_mode)
                paytm_payments.utils.add_logs(f"read_write_on_terminal() :: Request Send To Device : {request}", debug_mode)

                size = 0
                start = time.perf_counter()
                end = start

                while ((end - start) <  read_write_timeout):
                    bytesToRead = serial_port.in_waiting
                    if bytesToRead > 0:
                        # payments.utils.add_logs(f"bytesToRead in Input Buffer : {bytesToRead}", debug_mode)
                        if len(response) == 0:
                            response_data_length: bytes = serial_port.read(4)
                            size = int(response_data_length.decode('utf-8'))
                            paytm_payments.utils.add_logs(f"Size of Response from Device : {size}", debug_mode)
                        
                        if len(response) < size:
                            read_serial_data = serial_port.read(size - len(response))
                            if read_serial_data:
                                response = response + read_serial_data.decode('utf-8')
                                # payments.utils.add_logs(f"Response from Device : {response}", debug_mode)
                        if size - len(response) > 0:
                            paytm_payments.utils.add_logs(f"Remaining length of Data to be Read : {size - len(response)} ", debug_mode)
                            continue

                        if response and "requestId" in response:
                            paytm_payments.utils.add_logs(f"read_write_on_terminal() :: Response received From Device : {response}", debug_mode)
                            json_response: dict = json.loads(response)
                            data: dict = json_response.get("data")
                            if type(data) == str:
                                data = json.loads(data)

                            req_id = json_response.get("requestId")
                            checksum = json_response.get("checksum")
                            resp = json_response.get("command")
                            if order_id:
                                #:TODO revist code as return is same under different conditions
                                if request_id == req_id and order_id == data.get("orderId"):
                                    device_response = paytm_payments.models.DeviceResponse(checksum, json.dumps(data, separators=(',', ':')), resp, request_id)
                                    break
                            else:
                                if request_id == req_id:
                                    device_response = None
                                    device_response = paytm_payments.models.DeviceResponse(checksum, json.dumps(data, separators=(',', ':')), resp, request_id)
                                    break
                    end = time.perf_counter()
                if device_response:
                    paytm_payments.utils.add_logs(f"Device Response :: checksum {device_response.checksum} :: data {device_response.data} :: response {device_response.response} :: request_id {device_response.request_id}", debug_mode)
                else:
                    paytm_payments.utils.add_logs("Device Response is None", debug_mode)
                return device_response
            else:
                paytm_payments.utils.add_logs("read_write_on_terminal() :: serial_port is null, returning Error response from here", debug_mode)
                return paytm_payments.models.ErrorResponse(paytm_payments.constants.ErrorType.DeviceNotAvailable.name)
            
        except Exception:
            paytm_payments.utils.add_exception_logs(f"Exception in __read_write_on_terminal:: {traceback.format_exc()}", debug_mode)
        finally:
            self.__clear_buffers(serial_port, debug_mode)
            if serial_port:
                self.__disconnect(serial_port, debug_mode)


    @staticmethod
    def __get_unique_transaction_id(epochtime_in_milli: int) -> str:
        return str(epochtime_in_milli)
    
    def ConnectionCheck(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int):
        con_check = paytm_payments.activity_flow.ConnectionCheckActivityFlow()
        request_id: str = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())
        paytm_payments.utils.add_logs("connection_check() method called with following connection parameters", debugmode)
        paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
        try:
            request: str = con_check.process(request_id, debugmode)
            device_response = self.__read_write_on_terminal(port_name, baud_rate, parity, databits, stopbit, debugmode, request_id, None, request)
            verified_response = paytm_payments.checksum.HashHelper.parse_response_data(device_response)
            paytm_payments.utils.add_logs(f"Response from ConnectionCheck :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"connection_check() :: Error Response {error_response.to_string()} {traceback.format_exc()}", debugmode)
            return error_response.to_string()
        
    def Sale(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int, merchant_id: str, order_id: str, payment_mode: str, amount: str, sub_wallet_info: str, extend_info: str, print_info: str, gst_information: str, card_read_mode: str):
        try:
            paytm_payments.utils.add_logs("Sale method called with following connection parameters", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)

            if not os.path.isfile(Payments.CONFIG_FILE_PATH):
                raise Exception("Please provide PaytmPayments.json at root path of project")
            
            with open(Payments.CONFIG_FILE_PATH) as user_file:
                file_contents = user_file.read()
            file_contents = json.loads(file_contents)

            sale_activity_flow: SaleActivityFlow = paytm_payments.activity_flow.SaleActivityFlow()
            request_id: str = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())


            StatusCheckOnSaleRequestEnabled: bool = file_contents.get("StatusCheckOnSaleRequestEnabled", False)
            SaleRequestTimeout: int = file_contents.get("SaleRequestTimeout")
            StatusCheckInterval: int = file_contents.get("StatusCheckInterval")
            StatusCheckStart: int = file_contents.get("StatusCheckStart")
            SaleAckStatusCode: list = file_contents.get("SaleAckStatusCode", [])
            TransactionPendingStatusCodes: list = file_contents.get("TransactionPendingStatusCodes", [])

            request = sale_activity_flow.process(merchant_id, order_id, payment_mode,
                                       amount, sub_wallet_info, request_id, debugmode,
                                       extend_info, print_info, gst_information, card_read_mode)
            device_response: DeviceResponse = self.__read_write_on_terminal(port_name, baud_rate,
                                                                          parity, databits,
                                                                          stopbit, debugmode,request_id,
                                                                          order_id, request)
            
            start_time = paytm_payments.utils.date_time_now()
            verified_response: str = paytm_payments.checksum.HashHelper.parse_response_data(device_response)

            if StatusCheckOnSaleRequestEnabled:
                status_verified_response = None
                verified_response_dict: dict = json.loads(verified_response)
                sale_status_code = verified_response_dict.get("statusCode")
                if sale_status_code in SaleAckStatusCode:
                    time.sleep(StatusCheckStart-StatusCheckInterval)

                    while (paytm_payments.utils.date_time_now() - start_time) < (SaleRequestTimeout*1000):
                        time.sleep(StatusCheckInterval)
                        status_verified_response = self.Status(port_name, baud_rate, parity,
                                                                databits, stopbit, debugmode,
                                                                merchant_id, order_id)
                        
                        if status_verified_response:
                            status_verified_response_dict: dict = json.loads(status_verified_response)
                            status_code = status_verified_response_dict.get("statusCode")

                            if status_code not in TransactionPendingStatusCodes:
                                return status_verified_response
                    if status_verified_response:
                        verified_response = status_verified_response
            paytm_payments.utils.add_logs(f"Response from Sale :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"Sale() :: Error Response {error_response.to_string()} :: {traceback.format_exc()}", debugmode)
            return error_response.to_string()

    def Status(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int, merchant_id: str, order_id: str):

        status_query: StatusActivityFlow = paytm_payments.activity_flow.StatusActivityFlow()
        request_id = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())
        try:
            paytm_payments.utils.add_logs("Status method called with following connection parameters", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
            request = status_query.process(merchant_id, order_id, request_id, debugmode)
            device_response: DeviceResponse = self.__read_write_on_terminal(port_name, baud_rate,
                                                                          parity, databits,
                                                                          stopbit, debugmode,request_id,
                                                                          order_id, request)
            
            verified_response = paytm_payments.checksum.HashHelper.parse_response_data(device_response)
            paytm_payments.utils.add_logs(f"Response from Status :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"Status() :: Error Response {error_response.to_string()} {traceback.format_exc()}", debugmode)
            return error_response.to_string()

    def Void(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int, merchant_id: str, order_id: str, extend_info: str, print_info: str):
        try:
            paytm_payments.utils.add_logs("Void method called with following connection parameters", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
            void_flow: VoidActivityFlow = paytm_payments.activity_flow.VoidActivityFlow()
            request_id = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())
            request = void_flow.process(merchant_id, order_id, request_id, extend_info, print_info, debugmode)
            device_response: DeviceResponse = self.__read_write_on_terminal(port_name, baud_rate,
                                                                          parity, databits,
                                                                          stopbit, debugmode,request_id,
                                                                          order_id, request)
            verified_response = paytm_payments.checksum.HashHelper.parse_response_data(device_response)
            paytm_payments.utils.add_logs(f"Response from Void :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"Void() :: Error Response {error_response.to_string()} {traceback.format_exc()}")
            return error_response.to_string()

    def Cancel(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int, merchant_id: str, order_id: str):
        try:
            paytm_payments.utils.add_logs("Cancel method called with following connection parameters", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
            cancel_flow: CancelActivityFlow = paytm_payments.activity_flow.CancelActivityFlow()
            request_id = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())

            request = cancel_flow.process(merchant_id, order_id, request_id, debugmode)
            device_response: DeviceResponse = self.__read_write_on_terminal(port_name, baud_rate,
                                                                          parity, databits,
                                                                          stopbit, debugmode,request_id,
                                                                          order_id, request)
            
            verified_response = paytm_payments.checksum.HashHelper.parse_response_data(device_response)
            paytm_payments.utils.add_logs(f"Response from Cancel :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"Cancel() :: Error Response {error_response.to_string()} {traceback.format_exc()}", debugmode)
            return error_response.to_string()

    def PrintReceipt(self, port_name: str, baud_rate: int, parity: int, databits: int, stopbit: int, debugmode: int, merchant_id: str, order_id: str):
        print_receipt: PrintReceiptActivityFlow = paytm_payments.activity_flow.PrintReceiptActivityFlow()
        request_id: str = Payments.__get_unique_transaction_id(paytm_payments.utils.date_time_now())

        try:
            paytm_payments.utils.add_logs("PrintReceipt method called with following connection parameters", debugmode)
            paytm_payments.utils.add_logs(f"port_name {port_name} baud_rate {baud_rate} parity {parity} databits {databits} stopbit {stopbit} debugmode {debugmode}", debugmode)
            request: str = print_receipt.process(merchant_id, order_id, request_id, debugmode)
            device_response: DeviceResponse = self.__read_write_on_terminal(port_name, baud_rate, parity, databits, stopbit, debugmode, request_id, order_id, request)
            verified_response = paytm_payments.checksum.HashHelper.parse_response_data(device_response)
            paytm_payments.utils.add_logs(f"Response from PrintReciept :: {verified_response}", debugmode)
            return verified_response
        except Exception as e:
            error_response = paytm_payments.models.ErrorResponse(str(e))
            paytm_payments.utils.add_exception_logs(f"print_receipt :: Error Response {error_response.to_string()} {traceback.format_exc()}")
            return error_response.to_string()
        
    def __get_port_no(self, debugmode: int):
        try:
            if not os.path.isfile(Payments.CONFIG_FILE_PATH):
                raise Exception("Please provide PaytmPayments.json at root path of project")
            
            with open(Payments.CONFIG_FILE_PATH) as user_file:
                file_contents = user_file.read()
            file_contents = json.loads(file_contents)

            device_instances = file_contents.get("DeviceInstances")
            if not isinstance(device_instances, list):
                raise Exception("DeviceInstances in PaytmPayments.json must be a list of strings")

            ports = sorted(comports())
            for port, desc, hwid in ports:
                paytm_payments.utils.add_logs(f"PORT NAME :: {port} DESCRIPTION :: {desc} HARDWAREID :: {hwid}", debugmode)
                hwid_split = hwid.split(" ")
                if len(hwid_split) > 1:
                    device_id = hwid_split[1].strip()
                    if device_id in device_instances:
                        paytm_payments.utils.add_logs(f"__get_port_no returned {port.strip()}", debugmode)
                        return port.strip()
                    
            # If no matching port found
            paytm_payments.utils.add_logs("No matching device port found for configured DeviceInstances values", debugmode)
            return None
        
        except Exception as e:
            paytm_payments.utils.add_exception_logs(f"get_port_no :: {traceback.format_exc()}", debugmode)
            return None

