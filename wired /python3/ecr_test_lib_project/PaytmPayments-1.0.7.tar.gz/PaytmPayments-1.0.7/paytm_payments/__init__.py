import logging

try:
    logger = logging.getLogger('paytmpayments')
    logger.setLevel(logging.DEBUG)
    ch = logging.FileHandler('paytmpayments.log')
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)
except Exception:
    ...