import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()
  
setuptools.setup(
    name='PaytmPayments',
    version='1.0.7',
    description='EDC Python package for wired integration',
    author='Paytm',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author_email='',
    license='proprietary and confidential',
    packages=['paytm_payments'],
    install_requires=[
        'pyserial',
    ],
    python_requires='>=3.6'
)